backbone-skills
===============

simple backbone app for voting on skills

Site demoed at [ http://apollo.sfgeek.net/ ]( http://apollo.sfgeek.net/)

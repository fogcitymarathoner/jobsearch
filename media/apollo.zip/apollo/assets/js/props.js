/**
 * Created with IntelliJ IDEA.
 * User: Drew
 * Date: 3/26/13
 * Time: 7:49 AM
 * To change this template use File | Settings | File Templates.
 */
//remember these properties are client facing and thus insecure
var _appProps = {
    name: "Example Application",
    description: "This simple example application is to demonstrate Backbone.js and Twitter Bootstrap working together to create a responsive application. It also provides a simple and clean boilerplate for quickly starting a new Backbone.js powered Twitter Bootstrap themed web application.",
    author: "Drew Short",
    contact: "drew@sothr.com"
};